package com.example.dataviews

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
