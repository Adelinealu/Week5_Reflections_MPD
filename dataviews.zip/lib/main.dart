import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  final List<String> albums = [
    'assets/images/album1.jpg',
    'assets/images/album2.jpg',
    'assets/images/album3.jpg',
    'assets/images/album4.jpg',
    'assets/images/album5.jpg',
    'assets/images/album6.jpg',
    'assets/images/album7.jpg',
    'assets/images/album8.jpg',
    'assets/images/album9.jpg',
    'assets/images/album10.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Music App',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Israel Mbonyi Albums'),
        ),
        body: GridView.count(
          crossAxisCount: 2,
          children: List.generate(albums.length, (index) {
            return GestureDetector(
              onTap: () {
                // Navigate to album details page.
              },
              child: Card(
                elevation: 5,
                child: Column(
                  children: [
                    Expanded(
                      child: Image.asset(
                        albums[index],
                        fit: BoxFit.cover,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Album $index',
                        style: Theme.of(context).textTheme.subtitle1,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
